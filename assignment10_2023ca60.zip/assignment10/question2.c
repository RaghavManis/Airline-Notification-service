
// Write a C program to implement Rabin Karp String matching algorithm

#include <stdio.h>
#include <string.h>

#define d 256     // Number of characters in the input alphabet
#define q 101     // A prime number

void rabinKarp(char *text, char *pattern) {
    int textLength = strlen(text);
    int patternLength = strlen(pattern);
    int i, j;
    int patternHash = 0;    // Hash value for pattern
    int textHash = 0;       // Hash value for text
    int h = 1;

    // The value of h would be "pow(d, patternLength-1) % q"
    for (i = 0; i < patternLength - 1; i++) {
        h = (h * d) % q;
    }

    // Calculate the hash value of the pattern and first window of text
    for (i = 0; i < patternLength; i++) {
        patternHash = (d * patternHash + pattern[i]) % q;
        textHash = (d * textHash + text[i]) % q;
    }

    // Slide the pattern over text one by one
    for (i = 0; i <= textLength - patternLength; i++) {
        // Check if the hash values of current window of text and pattern match
        if (patternHash == textHash) {
            // Check for characters one by one if hash values match
            for (j = 0; j < patternLength; j++) {
                if (text[i + j] != pattern[j])
                    break;
            }

            // If patternHash == textHash and pattern[0...patternLength-1] == text[i, i+1, ...i+patternLength-1]
            if (j == patternLength) {
                printf("Pattern found at index %d\n", i);
            }
        }

        // Calculate hash value for next window of text
        if (i < textLength - patternLength) {
            textHash = (d * (textHash - text[i] * h) + text[i + patternLength]) % q;

            // If textHash is negative, convert it to positive
            if (textHash < 0) {
                textHash = (textHash + q);
            }
        }
    }
}

int main() {
    char text[100], pattern[100];

    printf("Enter the text: ");
    fgets(text, sizeof(text), stdin);
    text[strcspn(text, "\n")] = 0;  // Remove newline character from fgets input

    printf("Enter the pattern: ");
    fgets(pattern, sizeof(pattern), stdin);
    pattern[strcspn(pattern, "\n")] = 0;  // Remove newline character from fgets input

    rabinKarp(text, pattern);

    return 0;
}
