
// Given a string you need to print all possible strings that can be made by placing spaces (zero or one)
// in between them. E.g.
// Input: str[] = "ABC"
// Output: ABC
// AB C
// A BC
// A B C


#include <stdio.h>
#include <string.h>

void generateCombinations(char *str, char *result, int i, int j, int n) {
    // Base case: if we reach the end of the original string
    if (i == n) {
        result[j] = '\0';  // Null-terminate the current combination
        printf("%s\n", result);  // Print the result
        return;
    }

    // Include the current character without a space
    result[j] = str[i];
    generateCombinations(str, result, i + 1, j + 1, n);

    // Include the current character with a space if it's not the last character
    if (i < n - 1) {
        result[j] = str[i];
        result[j + 1] = ' ';
        generateCombinations(str, result, i + 1, j + 2, n);
    }
}

int main() {
    char str[100];
    printf("Enter the string: ");
    scanf("%s", str);

    int n = strlen(str);
    char result[2 * n];  // Maximum possible length if spaces are added between each character

    // Generate all combinations starting with the first character
    generateCombinations(str, result, 0, 0, n);

    return 0;
}
